from django.http import HttpResponse

# Create your views here.
def indexPageView(request):
    return HttpResponse('Welcome to Python R Us Programming!')

def aboutPageView(request):
    return HttpResponse('Our company is great!')

def contactPageView(request, fName, lName, email):
    return HttpResponse(f"Welcome {fName} {lName}! We will send an email to {email}!")